#!/usr/bin/env python

from distutils.core import setup


setup(
    name='rotating_logger',
    version='0.1.0',
    packages=['rotating_logger'],
    author='Romain MRAD',
    author_email='romain.mrad@gmail.com',
    url='https://github.com/romainmrad/rotating_logger.git',
)
